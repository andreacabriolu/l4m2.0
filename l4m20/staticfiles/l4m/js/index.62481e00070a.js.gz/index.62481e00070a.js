window.addEventListener('DOMContentLoaded', event => {

    // $(function() {
    //     $('#simObDataTable').DataTable();
    // });

    // const canvas = document.getElementById("can");
    // const ctx = canvas.getContext("2d");
    // ctx.fillStyle = "white";
    // ctx.fillRect(20, 20, canvas.width/7, canvas.height/7);

    const mainContainer = document.getElementById('main-div-container');
    

});

